#!/bin/bash
# ArkOS Sync Savefiles to Cloud
# By ridgek
