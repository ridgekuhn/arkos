#!/bin/bash
sudo apt remove python3-pyudev -y

echo "======================================================================"
echo "joy2key has been uninstalled, but some files must be deleted manually:"
echo "/opt/joy2key"
