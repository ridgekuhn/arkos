#!/bin/bash
/opt/joy2key/listen.sh "/opt/arklone/dialogs/settings.sh"
